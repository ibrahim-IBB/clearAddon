bl_info = {
    "name" : "ClearCanvas",
    "author" : "IbCoder", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "View 3D",
    "waring" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import bpy
import bpy.utils.previews


def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


addon_keymaps = {}
_icons = None
nodetree = {}


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_PT_GREASEPENCILTOOL_E35C1(bpy.types.Panel):
    bl_label = 'GreasePencilTool'
    bl_idname = 'SNA_PT_GREASEPENCILTOOL_E35C1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'GreasePencil'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'PAINT_GPENCIL'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.deleteall_bf020', text='DeleteAll', icon_value=0, emboss=True, depress=False)


class SNA_OT_Deleteall_Bf020(bpy.types.Operator):
    bl_idname = "sna.deleteall_bf020"
    bl_label = "DeleteAll"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not (not 'PAINT_GPENCIL'==bpy.context.mode)

    def execute(self, context):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT_GPENCIL')
        bpy.context.area.type = prev_context
        if (property_exists("bpy.context.active_object.data.layers.active.active_frame.strokes", globals(), locals()) and len(bpy.context.active_object.data.layers.active.active_frame.strokes) > 0):
            bpy.ops.gpencil.select_all('INVOKE_DEFAULT', action='SELECT')
            bpy.ops.gpencil.delete('INVOKE_DEFAULT', type='POINTS')
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='PAINT_GPENCIL')
        else:
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='PAINT_GPENCIL')
            bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_PT_GREASEPENCILTOOL_E35C1)
    bpy.utils.register_class(SNA_OT_Deleteall_Bf020)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_PT_GREASEPENCILTOOL_E35C1)
    bpy.utils.unregister_class(SNA_OT_Deleteall_Bf020)
